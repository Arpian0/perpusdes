<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Admin Webinars Translation
    |--------------------------------------------------------------------------
    */

    'webinars_list_page_title' => 'Daftar Media Belajar',
    'webinar' => 'Webinar',
    'webinars' => 'Webinar',
    'courses' => 'Media Belajar',
    'live_classes' => 'Kelas Langsung',
    'text_courses' => 'Ebook',
    'title' => 'Judul',
    'webinar_title' => 'Judul webinar',
    'webinar_status' => 'Status webinar',
    'start_date' => 'Tanggal Mulai',
    'end_date' => 'Tanggal Berakhir',
    'capacity' => 'Kapasitas',
    'price' => 'Harga',
    'description' => 'Deskripsi',
    'status' => 'Status',
    'course_type' => 'Jenis Media Belajar',
    'type_webinar' => 'Webinar',
    'type_text_lesson' => 'Ebook',
    'type_course' => 'Media Belajar',
    'type_webinars' => 'Webinar',
    'type_text_lessons' => 'Ebook',
    'type_courses' => 'Media Belajar',
    'teacher_name' => 'Nama Instruktur',
    'student' => 'Mahasiswa',
    'category_name' => 'Nama Kategori',
    'select_category' => 'Pilih Kategori',
    'select_teacher' => 'pilih nama instruktur',
    'select_status' => 'pilih status',
    'webinars_count' => 'Penghitungan webinar',
    'image_cover' => 'Sampul Gambar',
    'choose_image_cover' => 'pilih sampul gambar',
    'choose_video_demo' => 'pilih demo video',
    'video_demo' => 'Demo Video',
    'support' => 'Dukungan',
    'partner_instructor' => 'Instruktur Mitra',
    'subscribe' => 'Berlangganan',
    'create_field_title_placeholder' => '.',
    'new_page_lead' => 'Anda dapat membuat webinar baru.',
    'page_lists_lead' => 'Daftar webinar. Anda dapat mengedit atau menghapus setiap baris.',
    'search_webinar' => 'Telusuri webinar',

    'admin_webinars' => 'Webinar',
    'admin_webinars_list' => 'Daftar Webinar',
    'admin_webinars_create' => 'Buat webinar',
    'admin_webinars_edit' => 'Edit Webinar',
    'admin_webinars_delete' => 'Hapus webinar',

    'feature_webinars' => 'Media Unggulan Belajar',
    'feature_webinar_create' => 'buat webinar fitur',
    'page' => 'Halaman',
    'select_page' => 'pilih halaman',
    'page_home' => 'rumah',
    'page_categories' => 'Kategori',
    'page_home_categories' => 'Beranda dan kategori',

    'sale_count' => 'Jumlah penjualan',
    'file_sale_count' => 'laporkan penjualan',
    'session_sale_count' => 'Penjualan sesi',
    'lesson_sale_count' => 'Penjualan pelajaran',

    'not_conducted' => 'Tidak dilakukan',
    'conducted' => 'Dilakukan',

    'webinars_reports' => 'Laporan webinar',
    'webinars_reports_lists_lead' => 'Daftar laporan webinar. Anda dapat mengedit atau menghapus setiap baris.',

];
