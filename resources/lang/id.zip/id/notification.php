<?php

return [
'all_notifications'=>'Semua pemberitahuan',
'sender'=>'Pengirim',
'notifications_page_lists_lead'=>'Daftar pemberitahuan. Anda dapat mengedit atau menghapus...',
'send_notification'=>'Kirim pemberitahuan',
'edit_notification'=>'Edit pemberitahuan',
'empty_notifications'=>'Pemberitahuan kosong',
'email_ignore_msg'=>'Jika Anda tidak mengirimkan permintaan ini, abaikan saja.',
'send_noticeboard'=>'Kirim pemberitahuan baru',
'edit_noticeboard'=>'Edit pemberitahuan',
'post_notice'=>'Kirim pemberitahuan',
'receiver'=>'Penerima',
];
