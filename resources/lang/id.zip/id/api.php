<?php
return [
    'public' => [
        'retrieved' => 'data berhasil diambil',
        'stored' => ' item berhasil disimpan ',
        'deleted' => ' item berhasil dihapus ',
        'updated' => ' item berhasil diperbarui',
        'status' => ':item :status berhasil'
    ],
    'auth' => [
        'not_verified' => 'pengguna tidak diverifikasi',
        'invalid_register_method' => 'the register method is invalid',
        'already_registered' => 'pengguna sudah terdaftar',
        'login' => 'pengguna berhasil masuk',
        'registered' => 'pengguna berhasil mendaftar'
    ]

];
