<?php

return [

/*
|--------------------------------------------------------------------------
| Authentication & Password
|--------------------------------------------------------------------------
|
|
*/

'reset'=>'Kata sandi Anda telah disetel ulang!',
'sent'=>'Kami telah mengirim email untuk tautan setel ulang kata sandi Anda!',
'throttled'=>'Harap tunggu sebelum mencoba lagi.',
'token'=>'Tautan setel ulang sandi ini tidak valid.',
'user'=>"Tidak ada pengguna yang ditemukan dengan alamat email ini.",

];
