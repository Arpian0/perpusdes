<?php

return [

/*
|--------------------------------------------------------------------------
| Quiz & Certificates
|--------------------------------------------------------------------------
*/

'quiz'=>'Kuis',
'quizzes'=>'Kuis',
'my_quizzes'=>'Kuis saya',
'new_quiz'=>'kuis baru',
'edit_quiz'=>'Edit kuis',
'quiz_title'=>'judul kuis',
'number_of_attemps'=>'Jumlah percobaan',
'attempts'=>'Upaya',
'pass_mark'=>'Tanda lulus',
'grade'=>'Kelas',
'your_grade'=>'Nilai Anda',
'quiz_grade'=>'Kuis nilai',
'my_grade'=>'Nilai saya',
'certificate_included'=>'Sertifikat sudah termasuk',
'active_quiz'=>'Kuis aktif',
'results_statistics'=>'Statistik hasil',
'success_rate'=>'Tingkat keberhasilan',
'open_results'=>'Buka hasil',
'open_quizzes'=>'Buka kuis',
'all_quizzes'=>'Semua kuis',
'unlimited'=>'Tidak terbatas',

'multiple_choice'=>'Pilihan ganda',
'add_multiple_choice'=>'Tambahkan Pilihan ganda',
'descriptive'=>'Deskriptif',
'add_descriptive'=>'Tambahkan Deskriptif',
'empty_means_infinity'=>'Biarkan kosong untuk tidak terbatas',

'multiple_choice_question'=>'soal pilihan ganda',
'question_title'=>'judul pertanyaan',
'question_grade'=>'Nilai pertanyaan',

'add_an_answer'=>'Tambahkan jawaban',
'answer_title'=>'Judul jawaban',
'answer_image'=>'Jawab gambar (Opsional)',
'correct_answer'=>'Jawaban yang benar',
'current_answer_required'=>'Silakan pilih jawaban yang benar',
'correct'=>'Benar',

'new_descriptive_question'=>'Pertanyaan deskriptif baru',
'student'=>'Mahasiswa',
'students'=>'Siswa',
'instructors'=>'Guru',
'student_results'=>'Hasil Siswa',
'average'=>'Rata-rata',
'average_grade'=>'Nilai Rata-Rata',
'minimum_grade'=>'Nilai Minimal',
'passed'=>'Lulus',
'failed'=>'Gagal',
'failed_quizzes'=>'Kuis Gagal',
'waiting'=>'Menunggu',
'filter_quizzes'=>'Filter Kuis',
'filter_results'=>'Filter Hasil',
'quiz_or_webinar'=>'Kuis / Media belajar',
'show_only_active_quizzes'=>'Hanya tampilkan kuis aktif',
'show_only_open_results'=>'Hanya tampilkan hasil yang terbuka',

'create_a_quiz'=>'Buat kuis',
'quiz_no_result'=>'Tidak ada kuis yang dibuat!',
'quiz_no_result_hint'=>'Anda dapat membuat kuis dan membiarkan siswa mengevaluasi diri mereka sendiri.',

'quiz_result_no_result'=>'Tidak ada hasil yang tersedia.',
'quiz_result_no_result_hint'=>'Siswa Anda belum lulus kuis apa pun!',

'need_to_review'=>'Perlu peninjauan',

'level_identification_quiz'=>'kuis identifikasi tingkat',
'previous_question'=>'Pertanyaan sebelumnya',
'next_question'=>'Pertanyaan selanjutnya',
'remaining_time'=> 'waktu yang tersisa',
'download_certificate'=>'Unduh sertifikat',
'you_can_download_certificate'=>'Sekarang Anda dapat mengunduh sertifikat Anda.',

'status_failed_title'=>'Maaf, Anda gagal dalam ujian.',
'status_failed_hint'=>'Nilai lulus kuis adalah :min_grade tetapi nilai Anda adalah :user_grade.',

'status_waiting_title'=>'Tunggu hasilnya...',
'status_waiting_hint'=>"Kuis ini memiliki beberapa pertanyaan deskriptif sehingga hasilnya \n akan diinformasikan kepada Anda setelah ditinjau.",

'status_passed_title'=>'Selamat! Anda lulus ujian ini.',
'status_passed_hint'=>'Anda lulus ujian dengan nilai :grade .',
'cant_start_quiz'=>'Anda tidak dapat memulai kuis ini.',
'student_grade'=>'Nilai siswa',

'quiz_start'=>'Mulai kuis',
'quiz_status'=>'kuis status',
'my_results'=>'Hasil saya',
'results'=>'Hasil',
'result'=>'Hasil',


'achievements'=>'Prestasi',
'my_achievements_lists'=>'Daftar pencapaian saya',
'certificates_lists'=>'Daftar sertifikat',
'certificates_statistics'=>'Statistik sertifikat',
'active_certificates'=>'Sertifikat aktif',
'student_achievements'=>'Prestasi siswa',
'failed_students'=> 'Siswa gagal',
'filter_certificates'=>'Filter sertifikat',
'generated_certificates'=>'Sertifikat yang dihasilkan',
'certificates_no_result'=>'Tidak ada sertifikat untuk media belajar Anda!',
'certificates_no_result_hint'=>'Dengan membuat kuis yang menyertakan sertifikat, media belajar Anda akan lebih berharga.',

'my_certificates'=>'Sertifikat saya',
'my_certificates_statistics'=>'Statistik sertifikat saya',
'my_certificates_no_result'=>'Anda tidak memiliki sertifikat!',
'my_certificates_no_result_hint'=>'Anda dapat memperoleh sertifikat yang valid dengan mendaftar di media belajar.',

'quiz_chance_remained'=>':count peluang tersisa',
'student_answer'=>'Jawaban siswa',

'new_quiz_page_title'=>'Kuis Baru',
'quizzes_list_page_title'=>'Daftar kuis',
'quizzes_section'=>'Tidak Ada Bagian',
];
