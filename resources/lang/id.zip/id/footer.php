<?php

return [
'join'=>'Gabung',
'join_us_today'=>'Gabung dgn kami',
'subscribe_content'=>'#Kami akan mengirimkan penawaran dan diskon terbaik ke email Anda.',
'enter_email_here'=>'Masukkan email Anda disini',
];