<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Home 
    |--------------------------------------------------------------------------
    */

    'home_title'=>'Home',

    'slider_heading'=>'Nikmati pembelajaran online',
    'slider_hint'=>"Pendidikan online adalah salah satu pilihan terbaik untuk tumbuh \n belajar dari ebook & video pembelajaran",

    'slider_search_placeholder'=>'Cari media belajar...',
    'find'=>'Cari',

    'view_all'=>'Lihat Semua',
    // stats
    'teachers'=>'Guru',
    'skillful_teachers'=>'Guru Terampil',
    'skillful_teachers_hint'=>'Mulailah belajar dari guru berpengalaman.',

    'live_classes'=>'Kelas Langsung',
    'live_classes_hint'=>'Tingkatkan keterampilan Anda menggunakan alur pengetahuan langsung.',

    'happy_students'=>'Siswa Bahagia',
    'happy_students_hint'=>'Mendaftar di media belajar kami dan meningkatkan keterampilan mereka.',

    'offline_courses'=>'Media belajar Video',
    'offline_courses_hint'=>'Belajar tanpa batasan geografis & waktu.',

    'hours'=>'Jam',

    'featured_classes'=>'Media belajar Unggulan',
    'featured_webinars'=>'Media belajar Unggulan',
    'featured_classes_hint'=>'#Jelajahi media belajar unggulan dan jadilah terampil',

    'latest_classes'=>'Media belajar Terbaru',
    'latest_webinars'=>'Media belajar Terbaru',
    'latest_webinars_hint'=>'#Media belajar yang baru diterbitkan',

    'featured'=>'Unggulan',
    'downloadable'=>'Dapat diunduh',
    'download'=>'Unduh',
    'downloads'=>'Unduhan',

    'trending_categories'=>'Kategori Tren',
    'trending_categories_hint'=>'#Jelajahi topik pembelajaran yang sedang tren & populer',

    'best_sellers'=>'Media belajar Terlaris',
    'best_sellers_hint'=>'#Belajar dari media belajar laris',

    'best_rates'=>'Media belajar Nilai Terbaik',
    'best_rates_hint'=>'#Nikmati konten berkualitas tinggi dan berperingkat terbaik',

    'discount_classes'=>'Media belajar Diskon',
    'discount_classes_hint'=>'#Dapatkan media belajar dengan harga terbaru',

    'free_classes'=>'Media belajar Gratis',
    'free_classes_hint'=>'#Jangan lewatkan kesempatan belajar gratis',

    'testimonials'=>'Testimonial',
    'testimonials_hint'=>'#Apa kata pelanggan kami tentang kami',

    'subscribe_now'=>'Berlangganan Sekarang!',
    'subscribe_now_hint'=>'#Pilih paket langganan dan hemat!',

    'instructors'=>'Guru',
    'all_instructors'=>'Semua Guru',
    'instructors_hint'=>'#Belajar dari guru berpengalaman & terampil',
    'reserve_a_live_class'=>'Pesan rapat langsung',

    'organization'=>'Organisasi',
    'organizations'=>'Organisasi',
    'all_organizations'=>'Semua Organisasi',
    'organizations_hint'=>'#Organisasi pendidikan terbaik ada di sini untuk membantu Anda',

    'blog'=>'Blog',
    'all_blog'=>'Postingan Blog',
    'blog_hint'=>'#Jelajahi berita dan artikel terbaru',

    'platform_address'=>'Alamat',
    'order_summary'=>'Ringkasan Pesanan',
  	'blog_search_placeholder'=>'Cari postingan blog...',
];
