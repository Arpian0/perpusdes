<?php

return [
'search_anything'=>'Cari...',
'home'=>'Home',
'about_us'=>'Tentang kami',
'contact'=>'Kontak',
'blog'=>'Blog',
'terms'=>'Persyaratan',
'items'=>'Item',
'menu'=>'Menu',
'title'=>'Judul',
'start_a_live_class'=>'Mulai kelas pertemuan',
];
