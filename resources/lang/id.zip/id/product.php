<?php

return [

/*
|--------------------------------------------------------------------------
| Course page
|--------------------------------------------------------------------------
*/

'course'=>'Media belajar',
'courses'=>'Media belajar',
'text_course'=>'Media belajar Ebook/audio/video',
  	'video_course'=>'Media belajar Video',
'information'=>'Informasi',
'content'=>'Konten',
'review'=>'Tinjau',
'reviews'=>'Ulasan',

'Webinar_description'=>'Tentang Media belajar ini',

'post_comment'=>'Kirim komentar',
'post_review'=>'Kirim ulasan',

'comment_success_store'=>'Komentar berhasil dikirim!',
'comment_success_store_msg'=>'Komentar Anda akan diterbitkan setelah disetujui oleh admin.',

'guarantee_text'=>'Jaminan uang kembali 7 hari',

'product_designer'=>'Desainer Produk',

'content_quality'=>'Kualitas konten',
'instructor_skills'=> 'Keterampilan guru',
'purchase_worth'=>'Harga beli',
'support_quality'=> 'Mendukung kualitas',

'report_the_course'=>'Laporkan Media belajar',
'reason'=>'Alasan',
'select_reason'=>'Pilih alasan',
'report_modal_hint'=>'Mohon jelaskan tentang laporan tersebut secara singkat dan jelas.',
];
