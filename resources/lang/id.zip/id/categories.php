<?php

return [
'categories'=>'Kategori',
'edit_page_title'=>'Ubah',
];
