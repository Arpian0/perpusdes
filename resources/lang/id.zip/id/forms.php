<?php

return [
'maximum_64_characters'=>'Maksimal 64 karakter',
'maximum_255_characters'=>'Maksimal 255 karakter',
'maximum_128_characters'=>'Maksimal 128 karakter',
'50_160_characters_preferred'=>'dianjurkan 50 - 160 karakter',
'maximum_50_characters'=>'Maksimal 50 karakter',
'course_thumbnail_size'=>'360x250px dianjurkan',
'course_cover_size'=>'1920x530px dianjurkan',
'max'=>'Maks',
'capacity_placeholder'=>'Berapa banyak siswa yang akan terdaftar/datang ?',
'subscribe_hint'=>'Siswa akan dapat berlangganan konten Anda selain pembelian langsung.',
'webinar_description_placeholder'=>'Minimal 300 kata. HTML dan gambar didukung.',
'empty_means_unlimited'=>'Biarkan kosong agar tidak terbatas.',
];